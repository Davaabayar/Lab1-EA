package edu.mum.cs544;

public interface IProductService {
	public Product getProduct(int productNumber);
}
