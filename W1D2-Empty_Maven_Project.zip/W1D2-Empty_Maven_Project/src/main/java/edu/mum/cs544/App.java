package edu.mum.cs544;

public class App {
    public static void main(String[] args) {
        System.out.println("FIXME: Empty Project");
    } 
}
