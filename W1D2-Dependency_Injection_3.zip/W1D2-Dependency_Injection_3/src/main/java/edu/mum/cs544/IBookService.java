package edu.mum.cs544;

public interface IBookService {
    public void buy(Book book);
}
